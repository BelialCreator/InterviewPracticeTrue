﻿using InterviewTrue.Main.BL.Helpers;
using InterviewTrue.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Net;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using RestSharp;
using Environment = InterviewTrue.Models.Environment;

namespace InterviewTrue.Main.BL
{
    public class RestMicroService
    {
        public RestMicroService()
        {
            Context = new MicroServiceDbContext();
            Client = new RestClient();
            Request = new RestRequest();
        }

        public MicroServiceDbContext Context { get; set; }

        public RestClient Client { get; set; }

        public RestRequest Request { get; set; }

        public string SetRequest(EndPointVerb endPoint = null, string env = null)
        {
            var microserviceName = endPoint.MicroserviceName;
            var moduleName = endPoint.ControllerName;
            var verbActionName = endPoint.ActionName;
            var parameter = endPoint.Parameters;

            Environment environment = ManageDataContext.GetEnvironment(microserviceName, env);
            Verb verb = ManageDataContext.GetVerb(microserviceName, moduleName, verbActionName);
            this.Client = new RestClient(environment.Url);

            this.SetMethodRest(verb.Type, verb.EndPoint);
            if (parameter != null)
            {
                var parameterEntities = ManageDataContext.GetParameter(microserviceName, moduleName, verbActionName);
                foreach (var item in parameter)
                {
                    var parameterEntity = parameterEntities.Find(u => u.Name.Equals(item.Key));
                    if (parameterEntity.Type.Equals("query"))
                    {
                        this.Request.AddParameter(item.Key, item.Value, ParameterType.QueryString);
                    }
                    else if (parameterEntity.Type.Equals("path"))
                    {
                        this.Request.AddParameter(item.Key, item.Value, ParameterType.UrlSegment);
                    }
                    else if (parameterEntity.Type.Equals("body"))
                    {
                        this.Request.AddParameter(item.Key, item.Value, ParameterType.GetOrPost);
                    }
                    else if (parameterEntity.Type.Equals("Authorization"))
                    {
                        SetBearerToken(item.Value);
                    }
                }
            }

            SetHeader(microserviceName, env);
            return Client.BuildUri(Request).ToString();
        }

        public void SetHeader(string microserviceName, string environment)
        {
            var headers = ManageDataContext.GetEnvironment(microserviceName, environment).Users;
            if (headers != null && headers.Count > 0)
            {
                foreach (var header in headers)
                {
                    if (header.Identifier == "application/x-www-form-urlencoded")
                    {
                        //this.Request.AddParameter(header.Identifier.ToString(), Dc.Execute(header.UserName), ParameterType.RequestBody);
                    }
                    else
                    {
                        //this.Request.AddHeader(header.Identifier.ToString(), Dc.Execute(header.UserName.ToString()));
                    }
                }
            }
        }

        public void SetBearerToken(string token)
        {
            this.Request.AddHeader("Authorization", $"Bearer {token}");
            this.Request.AddHeader("Content-Type", "application/json");
        }

        /// <summary>
        /// Set body json for request
        /// </summary>
        /// <param name="json">Json Request</param>
        /// <returns>Json request</returns>
        public JObject SetBodyRequest(object obj)
        {
            var json = obj.GetType().Name.Equals("String") ? obj.ToString() : ConvertToIndentedJson(obj);
            if (json.Equals("none"))
            {
                return JObject.Parse("{}");
            }
            else
            {
                JObject jsonRequestParse = JObject.Parse(json);
                try
                {
                    this.Request.AddParameter("application/json", jsonRequestParse, ParameterType.RequestBody);
                    this.Request.RequestFormat = DataFormat.Json;
                }
                catch (Exception e)
                {
                    throw;
                }

                return jsonRequestParse;

            }
        }

        public JArray SetBodyRequestArray(string json)
        {
            if (json.Equals("none"))
            {
                return JArray.Parse("[]");
            }
            else
            {
                JArray jsonRequestParse = JArray.Parse(json);
                try
                {
                    this.Request.AddParameter("application/json", jsonRequestParse, ParameterType.RequestBody);
                    this.Request.RequestFormat = DataFormat.Json;
                }
                catch (Exception e)
                {
                    throw;
                }

                return jsonRequestParse;

            }
        }

        /// <summary>
        /// Execute the request
        /// </summary>
        /// <returns>request <seealso cref="IRestResponse"/></returns>
        public IRestResponse GetResponse()
        {
            return this.Client.Execute(this.Request);
        }

        /// <summary>
        /// Convert Any object to Indented Json.
        /// </summary>
        /// <param name="jsonObject">Json object</param>
        /// <returns>Json serialize as string value.</returns>
        public static string ConvertToIndentedJson(object jsonObject)
        {
            JsonSerializerSettings jsonSettings = new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore
            };

            var initialJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented, jsonSettings);
            Regex rgx = new Regex($"\"{ConstantRest.Null}\"");
            var json = rgx.Replace(initialJson, "null");

            return json;
        }

        

        /// <summary>
        /// Gets the error message of response
        /// </summary>
        /// <param name="response">response of request</param>
        /// <returns>error message</returns>
        public dynamic GetErrorMessage(IRestResponse response)
        {
            dynamic content = (dynamic)JObject.Parse(response.Content);
            return content.ErrorMessage;
        }

        /// <summary>
        /// Gets path of microservice
        /// </summary>
        /// <param name="microservice">name of microservice</param>
        /// <returns>string path</returns>
        private static string GetPathMicroService(string microservice)
        {
            string context = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
            string[] splitContext = context.Split(Path.DirectorySeparatorChar);
            string newPath = string.Empty;
            foreach (string item in splitContext)
            {
                if (item.Equals("bin"))
                {
                    break;
                }

                newPath += item + "\\";
            }

            newPath += "Main\\" + microservice + "\\";
            return newPath;
        }

        public string JsonResponseSchema(EndPointVerb endPoint = null, string microserviceName = null, string moduleName = null, string verbType = null, string verbActionName = null)
        {
            // this is only temporary im going to fix this
            if (endPoint != null)
            {
                microserviceName = endPoint.MicroserviceName;
                moduleName = endPoint.ControllerName;
                verbActionName = endPoint.ActionName;
            }

            Environment environment = ManageDataContext.GetEnvironment(microserviceName);
            Verb verb = ManageDataContext.GetVerb(microserviceName, moduleName, verbActionName);

            string nameSpace = string.Format("IDT.MicroServices.Main.{0}.{1}.{2}.{3}", microserviceName, moduleName, "Response", verb.Response + ".json");
            string file;
            try
            {
                using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(nameSpace))
                using (StreamReader reader = new StreamReader(stream))
                {
                    file = reader.ReadToEnd();
                }
            }
            catch (Exception)
            {

                file = null;
            }

            return file;
        }

        private void SetMethodRest(string verbType, string endPoint)
        {
            switch (verbType)
            {
                case ConstantRest.Get:
                    Request = new RestRequest(endPoint, Method.GET);
                    break;
                case ConstantRest.Post:
                    Request = new RestRequest(endPoint, Method.POST);
                    break;
                case ConstantRest.Put:
                    Request = new RestRequest(endPoint, Method.PUT);
                    break;
                case ConstantRest.Delete:
                    Request = new RestRequest(endPoint, Method.DELETE);
                    break;
                case ConstantRest.Patch:
                    Request = new RestRequest(endPoint, Method.PATCH);
                    break;
                default:
                    break;
            }
        }
    }
}
