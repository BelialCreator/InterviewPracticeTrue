﻿namespace InterviewTrue.Main.BL.Helpers
{
    public class EndPointVerb
    {
        public string MicroserviceName { get; set; }

        public string ControllerName { get; set; }

        public string ActionName { get; set; }

        public Dictionary<string, string> Parameters { get; set; }
    }
}
