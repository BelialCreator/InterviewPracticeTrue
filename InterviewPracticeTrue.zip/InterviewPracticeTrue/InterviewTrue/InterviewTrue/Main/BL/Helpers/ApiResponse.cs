﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewTrue.Main.BL.Helpers
{
    public class ApiResponse<T>
    {
        public string Url { get; set; }
        public JObject SetBody { get; set; }
        public IRestResponse RoughResponse { get; set; }
        public string Method { get; set; }
        public T OResponse { get; set; }
        public string Type { get; set; }
        public string Time { get; set; }
        public List<string> resultSchema { get; set; }
    }
}
