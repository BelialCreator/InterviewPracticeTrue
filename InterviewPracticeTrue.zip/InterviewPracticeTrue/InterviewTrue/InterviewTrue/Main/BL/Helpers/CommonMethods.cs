﻿using Fare;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace InterviewTrue.Main.BL.Helpers
{
    public class CommonMethods
    {
        public delegate IRestResponse SendMethod();
        private static Random rnd;

        public static void Rand()
        {
            rnd = new Random();
        }

        /// <summary>
        /// Response time
        /// </summary>
        /// <param name="send">send</param>
        /// <returns>time</returns>
        public static CheckMethod GetValue(SendMethod send)
        {
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();
            var res = send();
            stopWatch.Stop();
            TimeSpan ts = stopWatch.Elapsed;
            int minutes = ts.Minutes;
            return new CheckMethod
            {
                Response = res,
                Time = $"{ts.Hours:00}:{minutes:00}:{ts.Seconds:00}.{ts.Milliseconds / 10:00}"
            };
        }

        /// <summary>
        /// Pathern string
        /// </summary>
        /// <param name="pathern">pathern</param>
        /// <returns>value</returns>
        public static string PatByRx(string pathern)
        {
            Rand();
            Thread.Sleep(5);
            Rand();
            Xeger val = new Fare.Xeger(pathern, rnd);
            return val.Generate();
        }

        /// <summary>
        /// compare attributes between entities
        /// </summary>
        /// <param name="objectA">To compare</param>
        /// <param name="objectB">Compared</param>
        /// <param name="exceptions">Exceptions</param>
        /// <returns>A boolean value</returns>
        public static bool CompareAttributeValues(object objectA, object objectB, params string[] exceptions)
        {
            bool allMatch = true;

            List<PropertyInfo> propertyInfo = new List<PropertyInfo>();
            foreach (var item in exceptions)
            {
                propertyInfo.Add(objectA.GetType().GetProperty(item));
            }

            List<PropertyInfo> listWithOutException = new List<PropertyInfo>();
            foreach (var item in objectA.GetType().GetProperties().ToList().Except(propertyInfo))
            {
                listWithOutException.Add(item);
            }

            listWithOutException.ToList().ForEach(origin =>
            {
                var valueEntity = objectB.GetType().GetProperty(origin.Name).GetValue(objectB, null);
                if (valueEntity != null && (origin.PropertyType == typeof(int) || origin.PropertyType == typeof(string) ||
                origin.PropertyType == typeof(decimal) || origin.PropertyType == typeof(bool) || origin.PropertyType == typeof(object)))
                {
                    TestContext.WriteLine($"{origin.Name} -> {origin.GetValue(objectA, null).ToString()} == {valueEntity.ToString()}");
                    allMatch = allMatch && origin.GetValue(objectA, null).ToString() == valueEntity.ToString();
                    if (!allMatch)
                    {
                        TestContext.WriteLine($"The the value of the attribute {origin.Name} doesn't match!.");
                    }
                }
            });

            return allMatch;
        }

        /// <summary>
        /// Json differences
        /// </summary>
        /// <param name="expected">expected</param>
        /// <param name="actual">actual</param>
        /// <returns>JsonDifferences</returns>
        public static JToken JsonDifferences(JToken expected, JToken actual)
        {
            if (JToken.DeepEquals(expected, actual)) return null;

            if (expected != null && actual != null && expected?.GetType() != actual?.GetType())
                throw new InvalidOperationException($"Operands' types must match; '{expected.GetType().Name}' <> '{actual.GetType().Name}'");

            var propertyNames = (expected?.Children() ?? default).Union(actual?.Children() ?? default)?.Select(_ => (_ as JProperty)?.Name)?.Distinct();

            if (!propertyNames.Any() && (expected is JValue || actual is JValue))
            {
                return (expected == null) ? actual : expected;
            }

            var difference = JToken.Parse("{}");

            foreach (var property in propertyNames)
            {
                if (property == null)
                {
                    if (expected == null)
                    {
                        difference = actual;
                    }
                    // array of object?
                    else if (expected is JArray && expected.Children().All(c => !(c is JValue)))
                    {
                        var difrences = new JArray();
                        //var mode = second == null ? '-' : '*';
                        var maximum = Math.Max(expected?.Count() ?? 0, actual?.Count() ?? 0);

                        for (int i = 0; i < maximum; i++)
                        {
                            var firstsItem = expected?.ElementAtOrDefault(i);
                            var secondsItem = actual?.ElementAtOrDefault(i);

                            var diff = JsonDifferences(firstsItem, secondsItem);

                            if (diff != null)
                            {
                                difrences.Add(diff);
                            }
                        }

                        if (difrences.HasValues)
                        {
                            difference/*[$"{mode}{property}"] */= difrences;
                        }
                    }
                    else
                    {
                        difference = expected;
                    }

                    continue;
                }

                if (expected?[property] == null)
                {
                    var secondVal = actual?[property]?.Parent as JProperty;

                    difference[$"+{property}"] = secondVal.Value;

                    continue;
                }

                if (actual?[property] == null)
                {
                    var firstVal = expected?[property]?.Parent as JProperty;

                    difference[$"-{property}"] = firstVal.Value;

                    continue;
                }

                if (expected?[property] is JValue value)
                {
                    if (!JToken.DeepEquals(expected?[property], actual?[property]))
                    {
                        difference[$"*{property}"] = value;
                    }

                    continue;
                }

                if (expected?[property] is JObject)
                {
                    var mode = actual?[property] == null ? '-' : '*';
                    var firstsItem = expected[property];
                    var secondsItem = actual[property];

                    var diffrence = JsonDifferences(firstsItem, secondsItem);

                    if (diffrence != null /*&& diffrence.Count() > 0*/)
                    {
                        difference[$"{mode}{property}"] = diffrence;
                    }

                    continue;
                }

                if (expected?[property] is JArray)
                {
                    var difrences = new JArray();
                    var mode = actual?[property] == null ? '-' : '*';
                    var maximum = Math.Max(expected?[property]?.Count() ?? 0, actual?[property]?.Count() ?? 0);

                    for (int i = 0; i < maximum; i++)
                    {
                        var firstsItem = expected[property]?.ElementAtOrDefault(i);
                        var secondsItem = actual[property]?.ElementAtOrDefault(i);

                        var diff = JsonDifferences(firstsItem, secondsItem);

                        if (diff != null)
                        {
                            difrences.Add(diff);
                        }
                    }

                    if (difrences.HasValues)
                    {
                        difference[$"{mode}{property}"] = difrences;
                    }

                    continue;
                }
            }

            return difference;
        }
    }
}
