﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewTrue.Main.BL.Helpers
{
    public class CheckMethod
    {
        public IRestResponse Response { get; set; }
        public string Time { get; set; }
    }
}
