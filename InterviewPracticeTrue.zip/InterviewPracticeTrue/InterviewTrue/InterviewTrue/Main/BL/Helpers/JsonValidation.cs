﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Schema;
using NUnit.Framework;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewTrue.Main.BL.Helpers
{
    public class JsonValidation
    {
        /// <summary>
        /// Validate a json schema
        /// </summary>
        /// <param name="response">Response API.</param>
        /// <param name="schemaResponse">Schema Response</param>
        /// <returns>boolean</returns>
        public static bool ValidateSchema(IRestResponse response, string schemaResponse)
        {
            JSchema sch = JSchema.Parse(schemaResponse);
            JObject obj = JObject.Parse(response.Content);

            IList<ValidationError> errors;
            bool valid = obj.IsValid(sch, out errors);
            ErrorMessage(errors);
            return valid;
        }

        /// <summary>
        /// Handled the error of the schema
        /// </summary>
        /// <param name="errors">List of errors after validation of Schema</param>
        private static void ErrorMessage(IList<ValidationError> errors)
        {
            foreach (var error in errors)
            {
                var words = error.Message.Split();
                switch (words.First())
                {
                    case ConstantRest.Property:
                        TestContext.WriteLine("Schema ERROR " + error.Message);
                        break;
                    case ConstantRest.Invalid:
                        TestContext.WriteLine("Schema ERROR " + "'" + error.Path + "'" + " " + error.Message);
                        break;
                    case ConstantRest.Required:
                        TestContext.WriteLine("Schema ERROR " + "'" + words.Last() + "'" + " " + "Missing property");
                        break;
                    default:
                        TestContext.WriteLine(error.Message);
                        break;
                }
            }
        }

        /// <summary>
        /// Result Schema
        /// </summary>
        /// <param name="response">schemaResponse</param>
        /// <param name="schemaResponse">response</param>
        /// <returns>list errors</returns>
        public static List<string> ResultSchema(string content, string schemaResponse)
        {
            List<string> schemaErrors = new List<string>();
            IList<ValidationError> errors;
            if (content != null && schemaResponse != null)
            {

                JSchema sch = JSchema.Parse(schemaResponse);
                JObject obj = JObject.Parse(content);

                bool valid = obj.IsValid(sch, out errors);
                foreach (var error in errors)
                {
                    var words = error.Message.Split();
                    switch (words.First())
                    {
                        case ConstantRest.Property:
                            schemaErrors.Add("Schema ERROR " + error.Message);
                            break;
                        case ConstantRest.Invalid:
                            schemaErrors.Add("Schema ERROR " + "'" + error.Path + "'" + " " + error.Message);
                            break;
                        case ConstantRest.Required:
                            schemaErrors.Add("Schema ERROR " + "'" + words.Last() + "'" + " " + "Missing property");
                            break;
                        default:
                            schemaErrors.Add(error.Message);
                            break;
                    }
                }

                return schemaErrors;
            }

            return null;
        }
    }
}
