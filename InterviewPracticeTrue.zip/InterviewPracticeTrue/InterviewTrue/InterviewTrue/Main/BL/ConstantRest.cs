﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewTrue.Main.BL
{
    public class ConstantRest
    {
        // Schema validations
        public const string Property = "Property";
        public const string Invalid = "Invalid";
        public const string Required = "Required";

        // Methods
        public const string Get = "GET";
        public const string Post = "POST";
        public const string Put = "PUT";
        public const string Delete = "DELETE";
        public const string Patch = "PATCH";

        // Status
        public const int Ok = 200;
        public const int Created = 201;
        public const int NoContent = 204;
        public const int NotModified = 304;
        public const int BadRequest = 400;
        public const int Forbidden = 403;
        public const int Conflict = 409;
        public const int Unauthorized = 401;
        public const int NotFound = 404;
        public const int InternalServerError = 500;
        public const int NotImplemented = 501;

        // Replace value
        public const string Null = "-...-.-...-..";
    }
}
