﻿using InterviewTrue.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Environment = InterviewTrue.Models.Environment;

namespace InterviewTrue.Main.BL
{
    public class ManageDataContext
    {
        private static MicroServiceDbContext context = new MicroServiceDbContext();

        public static Environment GetEnvironment(string microserviceName, string envName = null)
        {
            // Migration technical debt
            string environmentName = envName ?? "Master";
            if (environmentName == null)
            {
                // Migration technical debt
                environmentName = "Master";
            }

            return context.Microservices.Where(m => m.Name.Equals(microserviceName)).Include(m => m.Environments)
                .FirstOrDefault().Environments.Where(e => e.Name.Equals(environmentName)).FirstOrDefault();
        }

        public static Verb GetVerb(string microserviceName, string moduleName, string verbActionName)
        {
            return context.Microservices.Where(ms => ms.Name.Equals(microserviceName)).Include(m => m.Modules).ThenInclude(v=>v.Verbs).FirstOrDefault().Modules.Where(m => m.Name.Equals(moduleName)).FirstOrDefault()
                .Verbs.Where(v => v.ActionName.Equals(verbActionName)).FirstOrDefault();
        }

        public static Db GetDb(string microserviceName, string dbName, string envName = null)
        {
            return GetEnvironment(microserviceName, envName).Dbs.Where(d => d.Name.Equals(dbName)).FirstOrDefault();
        }

        public static List<Parameter> GetParameter(string microserviceName, string moduleName, string verbActionName)
        {
            return context.Microservices.Where(m => m.Name.Equals(microserviceName)).Include(m => m.Modules).ThenInclude(v => v.Verbs).ThenInclude(p=>p.Parameters)
                .FirstOrDefault().Modules.Where(e => e.Name.Equals(moduleName)).FirstOrDefault()
                .Verbs.Where(c => c.ActionName.Equals(verbActionName))
                .FirstOrDefault().Parameters.ToList();
        }

        public static MicroServiceDbContext GetContext()
        {
            return context;
        }
    }
}
