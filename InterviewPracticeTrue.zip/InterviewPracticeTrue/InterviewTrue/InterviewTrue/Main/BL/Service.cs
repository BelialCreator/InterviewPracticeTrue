﻿using InterviewTrue.Main.Truex.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewTrue.Main.BL
{
    public class Service
    {
        public static Truext Truext(string environment = null)
        {
            return new Truext(environment);
        }
    }
}
