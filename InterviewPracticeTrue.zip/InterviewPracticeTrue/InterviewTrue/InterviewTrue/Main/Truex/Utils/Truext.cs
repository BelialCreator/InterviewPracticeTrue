﻿namespace InterviewTrue.Main.Truex.Utils
{
    using System;
    using System.Collections.Generic;
    using InterviewTrue.Main.BL.Helpers;
    using InterviewTrue.Main.BL;
    using Newtonsoft.Json;
    using static InterviewTrue.Main.BL.Helpers.CommonMethods;

    public class Truext
    {
        public Truext(string environment = null)
        {
            this.environment = environment != null ? environment : "Master";
        }

        string environment;
        const string MicroserviceName = "Truext";
        public pet pet()
        {
            return new pet();
        }
    }
    public class pet
    {
        public findByStatus findByStatus(string status = null)
        {
            var apiParams = new Dictionary<string, object>();
            apiParams.Add("status", status);
            return new findByStatus(apiParams);
        }
    }
    public class findByStatus
    {
        public const string type = "GET";
        EndPointVerb endPointVerb = new EndPointVerb();
        RestMicroService restMicroservice;
        Dictionary<string, string> listClean = new Dictionary<string, string>();
        public findByStatus(Dictionary<string, object> list)
        {
            endPointVerb.MicroserviceName = "Truext";
            endPointVerb.ControllerName = "pet";
            endPointVerb.ActionName = "findByStatus";

            foreach (var item in list)
            {
                if (item.Value != null)
                {
                    listClean.Add(item.Key, item.Value.ToString());
                }
            }
            if (listClean.Count > 0)
            {
                endPointVerb.Parameters = listClean;
            }
        }

        public ApiResponse<T> Exec<T>(object obj = null)
        {
            restMicroservice = new RestMicroService();
            var url = restMicroservice.SetRequest(endPointVerb);
            var setBody = obj != null ? restMicroservice.SetBodyRequest(obj) : null;
            var res = CommonMethods.GetValue(new SendMethod(restMicroservice.GetResponse));
            T oResponse;
            try
            {
                oResponse = JsonConvert.DeserializeObject<T>(res.Response.Content);
            }
            catch (Exception e)
            {

                throw new InvalidOperationException($"*** {e.Message} Is not possible deserialize {url} : {res.Response.Content}");
            }
            var sch = JsonValidation.ResultSchema(res.Response.Content, restMicroservice.JsonResponseSchema(endPointVerb));

            return new ApiResponse<T>
            {
                Url = url,
                SetBody = setBody,
                RoughResponse = res.Response,
                OResponse = oResponse,
                Type = type,
                Time = res.Time,
                resultSchema = sch
            };
        }
    }
}
