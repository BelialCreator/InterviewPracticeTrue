﻿using InterviewTrue.Main.BL;
using InterviewTrue.Main.Truex.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewTrue.Test.Truex
{
    public class Truextests
    {
        [Fact]
        public void C00()
        {
            var availablePets = Service.Truext().pet().findByStatus("available").Exec<List<Pet>>();
        }
    }
}
