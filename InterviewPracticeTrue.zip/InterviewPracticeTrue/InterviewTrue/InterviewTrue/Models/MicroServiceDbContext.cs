﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace InterviewTrue.Models;

public partial class MicroServiceDbContext : DbContext
{
    public MicroServiceDbContext()
    {
    }

    public MicroServiceDbContext(DbContextOptions<MicroServiceDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Db> Dbs { get; set; }

    public virtual DbSet<Environment> Environments { get; set; }

    public virtual DbSet<Microservice> Microservices { get; set; }

    public virtual DbSet<Module> Modules { get; set; }

    public virtual DbSet<Parameter> Parameters { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<Verb> Verbs { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlite("Data Source=D:\\InterviewPracticeTrue\\InterviewTrue\\InterviewTrue\\Source\\MicroServiceDB.db");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Db>(entity =>
        {
            entity.HasKey(e => e.IdDb);

            entity.ToTable("Db");

            entity.HasIndex(e => e.IdDb, "IX_Db_IdDb").IsUnique();

            entity.HasOne(d => d.Environment).WithMany(p => p.Dbs).HasForeignKey(d => d.EnvironmentId);
        });

        modelBuilder.Entity<Environment>(entity =>
        {
            entity.HasKey(e => e.IdEnvironment);

            entity.ToTable("Environment");

            entity.HasIndex(e => e.IdEnvironment, "IX_Environment_IdEnvironment").IsUnique();

            entity.HasOne(d => d.Microservice).WithMany(p => p.Environments).HasForeignKey(d => d.MicroserviceId);
        });

        modelBuilder.Entity<Microservice>(entity =>
        {
            entity.HasKey(e => e.IdMicroservice);

            entity.ToTable("Microservice");

            entity.HasIndex(e => e.IdMicroservice, "IX_Microservice_IdMicroservice").IsUnique();
        });

        modelBuilder.Entity<Module>(entity =>
        {
            entity.HasKey(e => e.IdModule);

            entity.ToTable("Module");

            entity.HasIndex(e => e.IdModule, "IX_Module_IdModule").IsUnique();

            entity.HasOne(d => d.Microservice).WithMany(p => p.Modules).HasForeignKey(d => d.MicroserviceId);
        });

        modelBuilder.Entity<Parameter>(entity =>
        {
            entity.HasKey(e => e.IdParameter);

            entity.ToTable("Parameter");

            entity.HasIndex(e => e.IdParameter, "IX_Parameter_IdParameter").IsUnique();

            entity.HasOne(d => d.Verb).WithMany(p => p.Parameters).HasForeignKey(d => d.VerbId);
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.IdUser);

            entity.ToTable("User");

            entity.HasIndex(e => e.IdUser, "IX_User_IdUser").IsUnique();

            entity.HasOne(d => d.Environment).WithMany(p => p.Users).HasForeignKey(d => d.EnvironmentId);
        });

        modelBuilder.Entity<Verb>(entity =>
        {
            entity.HasKey(e => e.IdVerb);

            entity.ToTable("Verb");

            entity.HasIndex(e => e.IdVerb, "IX_Verb_IdVerb").IsUnique();

            entity.HasOne(d => d.Module).WithMany(p => p.Verbs).HasForeignKey(d => d.ModuleId);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
