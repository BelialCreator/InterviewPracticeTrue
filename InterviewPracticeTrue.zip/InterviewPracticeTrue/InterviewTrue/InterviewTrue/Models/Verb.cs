﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace InterviewTrue.Models;

public partial class Verb
{
    public long IdVerb { get; set; }

    public string Type { get; set; } = null!;

    public string? EndPoint { get; set; }

    public string ActionName { get; set; } = null!;

    public string? Request { get; set; }

    public string? Response { get; set; }

    public long? ModuleId { get; set; }
    [JsonIgnore]
    public virtual Module? Module { get; set; }

    public virtual ICollection<Parameter> Parameters { get; } = new List<Parameter>();
}
