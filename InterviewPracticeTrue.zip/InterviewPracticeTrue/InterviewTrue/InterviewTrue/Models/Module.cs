﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace InterviewTrue.Models;

public partial class Module
{
    public long IdModule { get; set; }

    public string Name { get; set; } = null!;

    public long? MicroserviceId { get; set; }

    [JsonIgnore]
    public virtual Microservice? Microservice { get; set; }

    public virtual ICollection<Verb> Verbs { get; } = new List<Verb>();
}
