﻿using System;
using System.Collections.Generic;

namespace InterviewTrue.Models;

public partial class Parameter
{
    public long IdParameter { get; set; }

    public string Name { get; set; } = null!;

    public string Type { get; set; } = null!;

    public string ParameterType { get; set; } = null!;

    public string? Value { get; set; }

    public long? VerbId { get; set; }

    public virtual Verb? Verb { get; set; }
}
