﻿using System;
using System.Collections.Generic;

namespace InterviewTrue.Models;

public partial class Environment
{
    public long IdEnvironment { get; set; }

    public string? Name { get; set; }

    public string? Url { get; set; }

    public string? Token { get; set; }

    public long? MicroserviceId { get; set; }

    public virtual ICollection<Db> Dbs { get; } = new List<Db>();

    public virtual Microservice? Microservice { get; set; }

    public virtual ICollection<User> Users { get; } = new List<User>();
}
