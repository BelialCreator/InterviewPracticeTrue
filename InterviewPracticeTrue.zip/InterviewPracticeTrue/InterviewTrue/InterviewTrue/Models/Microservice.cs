﻿using System;
using System.Collections.Generic;

namespace InterviewTrue.Models;

public partial class Microservice
{
    public long IdMicroservice { get; set; }

    public string Name { get; set; } = null!;

    public virtual ICollection<Environment> Environments { get; } = new List<Environment>();

    public virtual ICollection<Module> Modules { get; } = new List<Module>();
}
